// 创建一个Panel
chrome.devtools.panels.create(

  // title
  'ChromeDevToolsExtensionExample',

  // iconPath
  null,

  // pagePath
  'mypanel.html'
);
